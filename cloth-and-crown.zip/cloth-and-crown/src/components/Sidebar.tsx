import { BuildingPicker } from './BuildingPicker';
import { EventLog } from './EventLog';

export function Sidebar() {
  return (
    <aside className="w-80 flex flex-col gap-3 p-3 bg-parchment-200/40 border-l-2 border-double border-ink-800/30 overflow-hidden">
      <BuildingPicker />
      <EventLog />
    </aside>
  );
}
