import { BUILDING_LIST } from '../data/buildings';
import { useGameStore } from '../store/gameStore';
import { BuildingDefinition } from '../types';

export function BuildingPicker() {
  const selectedBuilding = useGameStore((s) => s.selectedBuilding);
  const selectBuilding = useGameStore((s) => s.selectBuilding);
  const gold = useGameStore((s) => s.global.gold);
  const resources = useGameStore((s) => s.city.resources);

  const canAfford = (b: BuildingDefinition) => {
    const c = b.cost;
    if ((c.gold ?? 0) > gold) return false;
    if ((c.wood ?? 0) > resources.wood) return false;
    if ((c.stone ?? 0) > resources.stone) return false;
    return true;
  };

  return (
    <section className="bg-parchment-100 border border-ink-800/20 rounded-sm">
      <header className="px-3 py-2 border-b border-ink-800/20 bg-parchment-200/50">
        <h3 className="display text-xs text-ink-800">Buildings</h3>
      </header>
      <div className="flex flex-col p-2 gap-1">
        {BUILDING_LIST.map((b) => {
          const isSelected = selectedBuilding === b.type;
          const affordable = canAfford(b);
          const c = b.cost;
          return (
            <button
              key={b.type}
              type="button"
              onClick={() => selectBuilding(isSelected ? null : b.type)}
              disabled={!affordable}
              className={`text-left px-3 py-2 rounded-sm border transition ${
                isSelected
                  ? 'bg-gilt-400/30 border-gilt-500'
                  : affordable
                  ? 'bg-parchment-50 border-parchment-300 hover:bg-parchment-200'
                  : 'bg-parchment-100 border-parchment-200 opacity-50 cursor-not-allowed'
              }`}
            >
              <div className="flex items-baseline justify-between gap-2">
                <span className="display text-xs text-ink-900">{b.name}</span>
                <span className="num text-[10px] text-ink-600">
                  {[
                    c.gold ? `${c.gold}g` : null,
                    c.wood ? `${c.wood}w` : null,
                    c.stone ? `${c.stone}s` : null,
                  ]
                    .filter(Boolean)
                    .join(' · ')}
                </span>
              </div>
              <p className="text-xs italic text-ink-600 leading-snug mt-0.5">
                {b.description}
              </p>
            </button>
          );
        })}
      </div>
    </section>
  );
}
