import { useGameStore } from '../store/gameStore';
import { LogType } from '../types';

const ACCENT: Record<LogType, string> = {
  info: 'border-l-ink-400',
  success: 'border-l-forest-500',
  warning: 'border-l-gilt-500',
  danger: 'border-l-vermilion-500',
};

export function EventLog() {
  const log = useGameStore((s) => s.log);

  return (
    <section className="bg-parchment-100 border border-ink-800/20 rounded-sm flex flex-col flex-1 min-h-0">
      <header className="px-3 py-2 border-b border-ink-800/20 bg-parchment-200/50">
        <h3 className="display text-xs text-ink-800">Chronicle</h3>
      </header>
      <div className="flex flex-col gap-1.5 p-2 overflow-y-auto">
        {log.map((entry) => (
          <article
            key={entry.id}
            className={`pl-2 pr-1 py-1.5 border-l-4 ${ACCENT[entry.type]} bg-parchment-50/70`}
          >
            <div className="num text-[9px] uppercase tracking-wide text-ink-600">
              {entry.season} {entry.year}
            </div>
            <div className="text-sm text-ink-900 leading-snug">{entry.message}</div>
          </article>
        ))}
      </div>
    </section>
  );
}
