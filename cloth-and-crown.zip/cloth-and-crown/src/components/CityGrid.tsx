import { useGameStore } from '../store/gameStore';
import { Tile } from './Tile';

export function CityGrid() {
  const cityName = useGameStore((s) => s.city.name);
  const grid = useGameStore((s) => s.city.grid);
  const population = useGameStore((s) => s.city.resources.population);

  return (
    <div className="flex flex-col items-center gap-4 p-8 max-w-md mx-auto">
      <div className="text-center w-full">
        <h2 className="display text-2xl text-ink-900">{cityName}</h2>
        <p className="italic text-sm text-ink-600">
          a free commune of <span className="num">{population}</span> souls
        </p>
        <hr className="ornament-rule" />
      </div>
      <div
        className="grid gap-2 p-4 bg-parchment-200/60 border-2 border-ink-800/30 rounded-sm w-full"
        style={{ gridTemplateColumns: 'repeat(4, minmax(0, 1fr))' }}
      >
        {grid.map((tile) => (
          <Tile key={tile.id} tile={tile} />
        ))}
      </div>
      <p className="italic text-xs text-ink-600 text-center">
        Select a building from the margin, then mark its place on the city plot.
      </p>
    </div>
  );
}
