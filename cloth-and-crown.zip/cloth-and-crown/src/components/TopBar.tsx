import { useGameStore } from '../store/gameStore';

type Item = { key: string; label: string; value: number; accent?: boolean };

export function TopBar() {
  const year = useGameStore((s) => s.year);
  const season = useGameStore((s) => s.season);
  const global = useGameStore((s) => s.global);
  const r = useGameStore((s) => s.city.resources);

  const items: Item[] = [
    { key: 'gold', label: 'Gold', value: global.gold, accent: true },
    { key: 'food', label: 'Food', value: r.food },
    { key: 'wool', label: 'Wool', value: r.wool },
    { key: 'cloth', label: 'Cloth', value: r.cloth },
    { key: 'wood', label: 'Wood', value: r.wood },
    { key: 'stone', label: 'Stone', value: r.stone },
    { key: 'pop', label: 'Souls', value: r.population },
  ];

  return (
    <header className="bg-parchment-100 border-b-2 border-double border-ink-800/40">
      <div className="flex items-center justify-between gap-6 px-6 py-3 flex-wrap">
        <div className="flex items-baseline gap-3">
          <h1 className="display text-xl text-ink-900">Cloth &amp; Crown</h1>
          <span className="text-sm italic text-ink-600">Bruges</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {items.map((it) => (
            <div
              key={it.key}
              className={`flex flex-col items-center px-3 py-1 rounded-sm border ${
                it.accent
                  ? 'bg-gilt-400/20 border-gilt-500'
                  : 'bg-parchment-50 border-parchment-300'
              }`}
            >
              <span className="display text-[10px] text-ink-600">{it.label}</span>
              <span className="num text-base text-ink-900">{it.value}</span>
            </div>
          ))}
          <div className="flex flex-col items-center px-3 py-1 ml-2 rounded-sm bg-ink-800 text-parchment-50 border border-ink-900">
            <span className="display text-[10px] opacity-80">{season}</span>
            <span className="num text-base">{year}</span>
          </div>
        </div>
      </div>
    </header>
  );
}
