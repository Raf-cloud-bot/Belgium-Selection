import { CityTile, BuildingType } from '../types';
import { BUILDINGS } from '../data/buildings';
import { useGameStore } from '../store/gameStore';

interface Props {
  tile: CityTile;
}

const TILE_THEME: Record<BuildingType, { bg: string; border: string; text: string; mark: string }> = {
  farm: { bg: 'bg-amber-100', border: 'border-amber-500', text: 'text-amber-900', mark: '🌾' },
  wool_yard: { bg: 'bg-stone-100', border: 'border-stone-500', text: 'text-stone-800', mark: '☘' },
  weavery: { bg: 'bg-purple-100', border: 'border-purple-500', text: 'text-purple-900', mark: '⧖' },
  market: { bg: 'bg-emerald-100', border: 'border-emerald-600', text: 'text-emerald-900', mark: '✦' },
  woodcutter: { bg: 'bg-lime-100', border: 'border-lime-600', text: 'text-lime-900', mark: '⊥' },
  quarry: { bg: 'bg-slate-100', border: 'border-slate-500', text: 'text-slate-900', mark: '◊' },
};

export function Tile({ tile }: Props) {
  const selectedBuilding = useGameStore((s) => s.selectedBuilding);
  const placeBuilding = useGameStore((s) => s.placeBuilding);

  if (tile.building) {
    const def = BUILDINGS[tile.building];
    const theme = TILE_THEME[tile.building];
    return (
      <div
        className={`aspect-square flex flex-col items-center justify-center rounded-sm border-2 ${theme.bg} ${theme.border} ${theme.text}`}
        title={def.description}
      >
        <span className="text-2xl leading-none mb-1">{theme.mark}</span>
        <span className="display text-[9px] tracking-wide">{def.name}</span>
      </div>
    );
  }

  const canPlace = selectedBuilding !== null;

  return (
    <button
      type="button"
      onClick={() => canPlace && placeBuilding(tile.id)}
      disabled={!canPlace}
      className={`aspect-square flex items-center justify-center rounded-sm border-2 transition ${
        canPlace
          ? 'bg-parchment-50 border-dashed border-vermilion-500 hover:bg-gilt-400/30 cursor-pointer'
          : 'bg-parchment-100 border-parchment-300 cursor-default'
      }`}
    >
      {canPlace && <span className="display text-[10px] text-vermilion-600">+ Raise</span>}
    </button>
  );
}
