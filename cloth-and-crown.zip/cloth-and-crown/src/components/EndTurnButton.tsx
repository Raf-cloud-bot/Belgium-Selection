import { useGameStore } from '../store/gameStore';

export function EndTurnButton() {
  const endTurn = useGameStore((s) => s.endTurn);
  const resetGame = useGameStore((s) => s.resetGame);
  const season = useGameStore((s) => s.season);

  return (
    <div className="flex items-center justify-between gap-3 px-6 py-3 bg-parchment-100 border-t-2 border-double border-ink-800/40">
      <button
        type="button"
        onClick={() => {
          if (window.confirm('Begin again? The chronicle so far will be lost.')) {
            resetGame();
          }
        }}
        className="display text-xs text-ink-600 hover:text-vermilion-600 transition"
      >
        Begin Anew
      </button>
      <button
        type="button"
        onClick={endTurn}
        className="display px-6 py-2.5 bg-ink-800 hover:bg-ink-900 text-parchment-50 text-sm border border-gilt-500 shadow"
      >
        Close {season} →
      </button>
    </div>
  );
}
