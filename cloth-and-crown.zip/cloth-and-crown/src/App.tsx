import { TopBar } from './components/TopBar';
import { CityGrid } from './components/CityGrid';
import { Sidebar } from './components/Sidebar';
import { EndTurnButton } from './components/EndTurnButton';

export default function App() {
  return (
    <div className="h-full flex flex-col bg-parchment-50">
      <TopBar />
      <div className="flex-1 flex overflow-hidden">
        <main className="flex-1 overflow-y-auto">
          <CityGrid />
        </main>
        <Sidebar />
      </div>
      <EndTurnButton />
    </div>
  );
}
