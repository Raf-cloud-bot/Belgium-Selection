import { GameState, CityTile } from '../types';

export const GRID_SIZE = 4;

function createEmptyGrid(): CityTile[] {
  const tiles: CityTile[] = [];
  for (let i = 0; i < GRID_SIZE * GRID_SIZE; i++) {
    tiles.push({
      id: i,
      row: Math.floor(i / GRID_SIZE),
      col: i % GRID_SIZE,
      building: null,
    });
  }
  return tiles;
}

export function buildInitialState(): GameState {
  return {
    year: 1200,
    season: 'Spring',
    global: { gold: 100 },
    city: {
      name: 'Bruges',
      resources: {
        food: 50,
        wool: 10,
        cloth: 0,
        wood: 20,
        stone: 10,
        population: 100,
      },
      grid: createEmptyGrid(),
    },
    log: [
      {
        id: 'chronicle-opens',
        year: 1200,
        season: 'Spring',
        message:
          'Spring of the Year of Our Lord 1200. The chronicle of Bruges opens. May your house prosper.',
        type: 'info',
      },
    ],
    selectedBuilding: null,
  };
}
