import { BuildingDefinition, BuildingType } from '../types';

export const BUILDINGS: Record<BuildingType, BuildingDefinition> = {
  farm: {
    type: 'farm',
    name: 'Farm',
    description: 'Tills the polders for grain. Idle through deep winter.',
    cost: { gold: 20, wood: 5 },
    produces: { food: 5 },
  },
  wool_yard: {
    type: 'wool_yard',
    name: 'Wool Yard',
    description: 'Pens for sheep and shorn fleeces. The seed of Flemish wealth.',
    cost: { gold: 20, wood: 5 },
    produces: { wool: 3 },
  },
  weavery: {
    type: 'weavery',
    name: 'Weavery',
    description: 'Looms turn raw wool into finished cloth.',
    cost: { gold: 30, wood: 8, stone: 2 },
    consumes: { wool: 2 },
    produces: { cloth: 2 },
  },
  market: {
    type: 'market',
    name: 'Market',
    description: 'Cloth sold on to the Hanse and Italian merchants.',
    cost: { gold: 30, wood: 6, stone: 4 },
    consumes: { cloth: 2 },
    produces: { gold: 10 },
  },
  woodcutter: {
    type: 'woodcutter',
    name: 'Woodcutter',
    description: 'A lodge in the forest belt. Steady timber.',
    cost: { gold: 10 },
    produces: { wood: 3 },
  },
  quarry: {
    type: 'quarry',
    name: 'Quarry',
    description: 'Hewn stone for cathedrals, walls, and weaveries.',
    cost: { gold: 25, wood: 5 },
    produces: { stone: 2 },
  },
};

export const BUILDING_LIST: BuildingDefinition[] = [
  BUILDINGS.farm,
  BUILDINGS.wool_yard,
  BUILDINGS.weavery,
  BUILDINGS.market,
  BUILDINGS.woodcutter,
  BUILDINGS.quarry,
];
