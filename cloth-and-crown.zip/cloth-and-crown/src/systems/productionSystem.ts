import { GameState, LogType, BuildingType } from '../types';
import { BUILDINGS } from '../data/buildings';
import { isWinter } from './seasonSystem';

type Logger = (msg: string, type?: LogType) => void;

const OUTDOOR_TYPES: ReadonlySet<BuildingType> = new Set([
  'farm',
  'woodcutter',
  'quarry',
]);

export function runProduction(state: GameState, log: Logger): GameState {
  const winter = isWinter(state.season);
  let { food, wool, cloth, wood, stone } = state.city.resources;
  let gold = state.global.gold;

  const produced: Record<string, number> = {};
  const idled: Record<string, number> = {};
  const starved: Record<string, number> = {};

  for (const tile of state.city.grid) {
    if (!tile.building) continue;
    const def = BUILDINGS[tile.building];

    if (winter && OUTDOOR_TYPES.has(tile.building)) {
      idled[def.name] = (idled[def.name] ?? 0) + 1;
      continue;
    }

    const c = def.consumes ?? {};
    if ((c.wool ?? 0) > wool || (c.cloth ?? 0) > cloth) {
      starved[def.name] = (starved[def.name] ?? 0) + 1;
      continue;
    }

    wool -= c.wool ?? 0;
    cloth -= c.cloth ?? 0;

    const p = def.produces ?? {};
    food += p.food ?? 0;
    wool += p.wool ?? 0;
    cloth += p.cloth ?? 0;
    wood += p.wood ?? 0;
    stone += p.stone ?? 0;
    gold += p.gold ?? 0;

    produced[def.name] = (produced[def.name] ?? 0) + 1;
  }

  const summarise = (rec: Record<string, number>) =>
    Object.entries(rec)
      .map(([name, n]) => `${n}× ${name}`)
      .join(', ');

  if (Object.keys(produced).length) {
    log(`Workshops produced: ${summarise(produced)}.`, 'info');
  }
  if (Object.keys(idled).length) {
    log(`Winter idled: ${summarise(idled)}.`, 'warning');
  }
  if (Object.keys(starved).length) {
    log(`Starved of input: ${summarise(starved)}.`, 'warning');
  }

  return {
    ...state,
    global: { gold },
    city: {
      ...state.city,
      resources: { ...state.city.resources, food, wool, cloth, wood, stone },
    },
  };
}
