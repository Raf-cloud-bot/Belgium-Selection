import { Season } from '../types';

export const SEASON_ORDER: Season[] = ['Spring', 'Summer', 'Autumn', 'Winter'];

export function nextSeason(
  current: Season,
  year: number
): { season: Season; year: number } {
  const idx = SEASON_ORDER.indexOf(current);
  if (idx === SEASON_ORDER.length - 1) {
    return { season: 'Spring', year: year + 1 };
  }
  return { season: SEASON_ORDER[idx + 1], year };
}

export function isWinter(season: Season): boolean {
  return season === 'Winter';
}
