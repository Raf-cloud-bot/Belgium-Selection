import { GameState, EventLogEntry, LogType } from '../types';
import { runProduction } from './productionSystem';
import { runConsumption } from './consumptionSystem';
import { nextSeason } from './seasonSystem';

const LOG_LIMIT = 200;

function makeStamp(year: number, season: GameState['season']) {
  return (msg: string, type: LogType = 'info'): EventLogEntry => ({
    id: `${year}-${season}-${Math.random().toString(36).slice(2, 9)}`,
    year,
    season,
    message: msg,
    type,
  });
}

export function processTurn(state: GameState): GameState {
  const entries: EventLogEntry[] = [];
  const stamp = makeStamp(state.year, state.season);
  const push = (msg: string, type: LogType = 'info') =>
    entries.push(stamp(msg, type));

  const afterProduction = runProduction(state, push);
  const afterConsumption = runConsumption(afterProduction, push);

  const { season: newSeason, year: newYear } = nextSeason(
    state.season,
    state.year
  );

  if (newSeason === 'Spring' && newYear !== state.year) {
    entries.push({
      id: `${newYear}-spring-banner`,
      year: newYear,
      season: 'Spring',
      message: `The year turns. Spring ${newYear} arrives.`,
      type: 'info',
    });
  }

  return {
    ...afterConsumption,
    season: newSeason,
    year: newYear,
    log: [...entries.reverse(), ...state.log].slice(0, LOG_LIMIT),
  };
}
