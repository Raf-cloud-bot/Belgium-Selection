import { GameState, LogType } from '../types';
import { isWinter } from './seasonSystem';

type Logger = (msg: string, type?: LogType) => void;

const NORMAL_DIVISOR = 20;
const WINTER_DIVISOR = 10;
const STARVATION_POP_LOSS = 5;

export function runConsumption(state: GameState, log: Logger): GameState {
  const winter = isWinter(state.season);
  const divisor = winter ? WINTER_DIVISOR : NORMAL_DIVISOR;
  const needed = Math.ceil(state.city.resources.population / divisor);

  let food = state.city.resources.food;
  let population = state.city.resources.population;

  if (food >= needed) {
    food -= needed;
    log(
      winter
        ? `Winter rations: ${needed} food consumed for ${population} souls.`
        : `Citizens consumed ${needed} food.`,
      'info'
    );
  } else {
    food = 0;
    population = Math.max(0, population - STARVATION_POP_LOSS);
    log(
      `Famine in ${state.season}. The granary is empty. Population falls by ${STARVATION_POP_LOSS}.`,
      'danger'
    );
  }

  return {
    ...state,
    city: {
      ...state.city,
      resources: { ...state.city.resources, food, population },
    },
  };
}
