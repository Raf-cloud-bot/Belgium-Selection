import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { GameState, BuildingType, EventLogEntry } from '../types';
import { buildInitialState } from '../data/initialState';
import { BUILDINGS } from '../data/buildings';
import { processTurn } from '../systems/turnSystem';

interface GameActions {
  selectBuilding: (type: BuildingType | null) => void;
  placeBuilding: (tileId: number) => void;
  endTurn: () => void;
  resetGame: () => void;
}

type GameStore = GameState & GameActions;

const QUARTER_NAMES = ['northern', 'eastern', 'southern', 'western'];

function rowLabel(row: number): string {
  return QUARTER_NAMES[row] ?? 'inner';
}

export const useGameStore = create<GameStore>()(
  persist(
    (set, get) => ({
      ...buildInitialState(),

      selectBuilding: (type) => set({ selectedBuilding: type }),

      placeBuilding: (tileId) => {
        const state = get();
        const { selectedBuilding, global, city } = state;
        if (!selectedBuilding) return;

        const tile = city.grid.find((t) => t.id === tileId);
        if (!tile || tile.building !== null) return;

        const def = BUILDINGS[selectedBuilding];
        const cost = def.cost;

        if ((cost.gold ?? 0) > global.gold) return;
        if ((cost.wood ?? 0) > city.resources.wood) return;
        if ((cost.stone ?? 0) > city.resources.stone) return;

        const newGrid = city.grid.map((t) =>
          t.id === tileId ? { ...t, building: selectedBuilding } : t
        );

        const entry: EventLogEntry = {
          id: `build-${tileId}-${Date.now()}`,
          year: state.year,
          season: state.season,
          message: `Raised a ${def.name} in the ${rowLabel(tile.row)} quarter.`,
          type: 'success',
        };

        set({
          global: { gold: global.gold - (cost.gold ?? 0) },
          city: {
            ...city,
            resources: {
              ...city.resources,
              wood: city.resources.wood - (cost.wood ?? 0),
              stone: city.resources.stone - (cost.stone ?? 0),
            },
            grid: newGrid,
          },
          log: [entry, ...state.log].slice(0, 200),
          selectedBuilding: null,
        });
      },

      endTurn: () => {
        set(processTurn(get()));
      },

      resetGame: () => set(buildInitialState()),
    }),
    {
      name: 'cloth-and-crown-save',
      version: 1,
    }
  )
);
