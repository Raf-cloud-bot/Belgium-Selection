export type Season = 'Spring' | 'Summer' | 'Autumn' | 'Winter';

export type BuildingType =
  | 'farm'
  | 'wool_yard'
  | 'weavery'
  | 'market'
  | 'woodcutter'
  | 'quarry';

export interface CityResources {
  food: number;
  wool: number;
  cloth: number;
  wood: number;
  stone: number;
  population: number;
}

export interface GlobalResources {
  gold: number;
}

export interface BuildingCost {
  gold?: number;
  wood?: number;
  stone?: number;
}

export interface BuildingProduction {
  food?: number;
  wool?: number;
  cloth?: number;
  wood?: number;
  stone?: number;
  gold?: number;
}

export interface BuildingConsumption {
  wool?: number;
  cloth?: number;
}

export interface BuildingDefinition {
  type: BuildingType;
  name: string;
  description: string;
  cost: BuildingCost;
  produces?: BuildingProduction;
  consumes?: BuildingConsumption;
}

export interface CityTile {
  id: number;
  row: number;
  col: number;
  building: BuildingType | null;
}

export interface City {
  name: string;
  resources: CityResources;
  grid: CityTile[];
}

export type LogType = 'info' | 'success' | 'warning' | 'danger';

export interface EventLogEntry {
  id: string;
  year: number;
  season: Season;
  message: string;
  type: LogType;
}

export interface GameState {
  year: number;
  season: Season;
  global: GlobalResources;
  city: City;
  log: EventLogEntry[];
  selectedBuilding: BuildingType | null;
}
